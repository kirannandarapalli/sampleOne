package com.forcamforce.office.utils;

/**
 * @author Kiran Nandarapalli
 *
 */

public class Report {
	
	@SuppressWarnings("unused")
	private static void initReport(){
		String runFolder = System.getProperty("report.runfolder", "");
		if(runFolder.isEmpty()) runFolder = "R{DATE}_{TIME}";
//		runFolder = runFolder.replace("{DATE}", DateHelper.getCurrentDatenTime("yyyyMMdd"))
//							.replace("{TIME}", DateHelper.getCurrentDatenTime("HHmmss"));
//		
//		resultsPath = "report/" + runFolder;
//
//		if(!new File(resultsPath).isDirectory())
//			new File(resultsPath).mkdirs();
	}

}
