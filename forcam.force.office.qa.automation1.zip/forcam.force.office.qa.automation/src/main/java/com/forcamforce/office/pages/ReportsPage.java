package com.forcamforce.office.pages;

import net.serenitybdd.core.pages.PageObject;

/**
 * @author Kiran Nandarapalli
 *
 */

public class ReportsPage extends PageObject {

	public void selectReport() {
		$("//*[@id='ffnewoffice-1277330532']//input").sendKeys("Operating State Class Report (Workplace)");
		$("//*[text()='Operating State Class Report (Workplace)']").click();
		$(".v-button.v-widget.ff-pdf-button.v-button-ff-pdf-button").waitUntilVisible();
		
	}

	public void selectWorkplaceAndClickRefresh() throws InterruptedException {
		$(".//*[@id='ffnewoffice-1277330532']/div/div[2]/div/div/div[2]/div/div/div[3]/div/div/div/div/div[2]/div/div/div[1]/div/div[7]/div/div[1]/div/div/div[2]").click();
		$("//*[text()='Select all']").click();
		$(".v-button.v-widget.ff-blue-faicon-button.v-button-ff-blue-faicon-button").click();
	}

	public void clicksPDFButton() {
		$(".v-button.v-widget.ff-pdf-button.v-button-ff-pdf-button").click();
		$("//*[text()='Download']").waitUntilClickable();
		
	}

	public void clickDownload() {
		$("//*[text()='Download']").click();
	}

	public void clickExcelButton() {
		$(".v-button.v-widget.ff-xls-button.v-button-ff-xls-button").click();
		
	}

}
