package com.forcamforce.office.steps;

import com.forcamforce.office.pages.LoginFFOfficePage;
import com.forcamforce.office.pages.ReportsPage;
import com.forcamforce.office.pages.VisualizationPage;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

/**
 * @author Kiran Nandarapalli
 *
 */

@SuppressWarnings("serial")
public class PerformanceAnalysis extends ScenarioSteps {
	
	LoginFFOfficePage login;
	ReportsPage reportsPage;
	VisualizationPage visPage;
	
	/** 
	 * Common steps for all features of Performance Analysis module 
	 * Login to application and navigation to Performance Analysis Module
	*/
	
	@Step
	public void opens_the_FFOfficeApplication() throws InterruptedException {
		login.open();
		getDriver().manage().window().maximize();			
	}
	
	@Step
	public void logged_into_the_FFOfficeApplication() throws InterruptedException {
		login.enteredLoginCredentials();
		
	}

	@Step
	public void clicked_the_performance_analysis_tab() throws InterruptedException {
		login.clickedPerformanceAnalysis();
		
	}

/*  Scenario: Export report to PDF */
	
	@Step
	public void clicked_reporting_tab() {
		login.clickedReportingtab();
		
	}

	@Step
	public void select_the_existing_report() {
		reportsPage.selectReport();
		
	}

	@Step
	public void selects_the_workplace_and_clicks_refresh_button() throws InterruptedException {
		reportsPage.selectWorkplaceAndClickRefresh();
		Thread.sleep(5000);
		
	}

	@Step
	public void cliks_the_Export_PDF_Button() {
		reportsPage.clicksPDFButton();
		
	}

	@Step
	public void click_the_Download_Button() throws InterruptedException {
		reportsPage.clickDownload();
		
	}

	
/* Scenario: Export visualization to PDF */
	
	@Step
	public void user_clicks_visualization_tab() {
		visPage.clicksVisulaizationTab();
		
	}
		
	}


