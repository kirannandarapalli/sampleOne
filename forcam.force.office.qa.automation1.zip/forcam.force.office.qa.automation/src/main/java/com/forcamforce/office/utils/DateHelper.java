package com.forcamforce.office.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author Kiran Nandarapalli
 *
 */

public class DateHelper {
	public static String getCurrentDate(String format){
		DateFormat dateFormat = new SimpleDateFormat(format);
		Date date = new Date();
		return dateFormat.format(date);
		}

		public static String getCurrentDatenTime(String format){
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(cal.getTime());
		}

			public static String getDateTimeDifference(String endDate, String startDate, String format){
			DateFormat dateFormat = new SimpleDateFormat(format);
			Date date1;
			Date date2;

			try{
			date1 = dateFormat.parse(endDate);
			date2 = dateFormat.parse(startDate);
			long timeDiff = date1.getTime() - date2.getTime();

			long diffSeconds = timeDiff / 1000 % 60;
			long diffMinutes = timeDiff / ( 60*1000) % 60;
			long diffHours = timeDiff / ( 60 * 60 * 1000) % 24;
			long diffDays = timeDiff / ( 24 * 60 * 60 * 1000);

			if(diffDays>0)
			return String.valueOf(diffDays + "days, " + diffHours + "hours, " + diffMinutes + "minutes, " + diffSeconds + "seconds.");

			else
			return String.valueOf(diffHours + "hours, " + diffMinutes + "minutes, " + diffSeconds + "seconds.");

			}

			catch(Exception e)
			{
			e.printStackTrace();
			return "";
			}
			}

}
