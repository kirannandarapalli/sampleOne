package com.forcamforce.office.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

/**
 * @author Kiran Nandarapalli
 *
 */

@DefaultUrl("http://fctestfactory15.cloudapp.net:19080/ffnewoffice/")
public class LoginFFOfficePage extends PageObject {
	
	
	public void enteredLoginCredentials() throws InterruptedException {
		$("#gwt-uid-5").sendKeys("SYSTEM");
		$("#gwt-uid-7").sendKeys("CHANGE");
		$("//*[text()='Login']").click();
		Thread.sleep(5000);	
	}

	public void clickedPerformanceAnalysis() throws InterruptedException {
		$("//*[text()='Performance Analysis']").click();
		$("//*[text()='Reporting']").waitUntilVisible();
	}

	public void clickedReportingtab() {
		$("//*[text()='Reporting']").click();
		$("//*[text()='Reports']").waitUntilVisible();
	}

}
