package com.forcamforce.office.utils;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Test;

/**
 * @author Kiran Nandarapalli
 *
 */

public class GenerateRandomNumber {
	
	public String generateRandomAlphaNumeric(int length){
		  return RandomStringUtils.randomAlphanumeric(length);
		 }
	
	 public String generateRandomNum(int length) {
		  String allowedChars= "1234567890";    //numbers
		  String randomName="";
		  String temp=RandomStringUtils.random(length,allowedChars);
		  randomName= "report" + temp.substring(0,temp.length()-9);
		  return randomName;
		 }


	 public void genRandomNumber() {
		String randomName = generateRandomNum(12);
		System.out.println(randomName);
	 }
}
