package com.forcamforce.office.pages;

import net.serenitybdd.core.pages.PageObject;

/**
 * @author Kiran Nandarapalli
 *
 */

public class VisualizationPage extends PageObject {

	public void clicksVisulaizationTab() {
		$("//*[text()='Visualization']").click();
		$("//*[text()='Views']").waitUntilVisible();
		
	}

}
