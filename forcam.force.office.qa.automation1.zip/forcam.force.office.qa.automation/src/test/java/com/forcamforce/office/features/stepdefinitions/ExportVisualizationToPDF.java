package com.forcamforce.office.features.stepdefinitions;

import com.forcamforce.office.steps.PerformanceAnalysis;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

/**
 * @author Kiran Nandarapalli
 *
 */

public class ExportVisualizationToPDF {

	@Steps
	PerformanceAnalysis vis;
	
	@Given("^user logged into FFOffice application$")
	public void user_logged_into_FFOffice_application() throws Throwable {
	 vis.opens_the_FFOfficeApplication();
	 vis.logged_into_the_FFOfficeApplication();
	    
	}

	@And("^user clicks the performance analysis module$")
	public void user_clicks_the_performance_analysis_module() throws Throwable {
		vis.clicked_the_performance_analysis_tab();
	   
	}

	@And("^user clicks on visualization tab$")
	public void user_clicks_on_visualization_tab() throws Throwable {
		vis.user_clicks_visualization_tab();

	}

	@When("^user selects the existing visualization in left navigation panel$")
	public void user_selects_the_existing_visualization_in_left_navigation_panel() throws Throwable {
	   
	}

	@Then("^user clicks on PDF icon and export$")
	public void user_clicks_on_PDF_icon_and_export() throws Throwable {
		
	}

}
