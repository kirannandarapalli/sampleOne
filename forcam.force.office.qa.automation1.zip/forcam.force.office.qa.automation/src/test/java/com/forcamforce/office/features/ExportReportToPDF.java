package com.forcamforce.office.features;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

/**
 * @author Kiran Nandarapalli
 *
 */

@RunWith(CucumberWithSerenity.class)	
@CucumberOptions(
		plugin = {"pretty", "html:target/cucumber-html-report"},
		features="src/test/resources/features/performance_analysis/reporting/ExportReportToPDF.feature")
public class ExportReportToPDF {
	
}
