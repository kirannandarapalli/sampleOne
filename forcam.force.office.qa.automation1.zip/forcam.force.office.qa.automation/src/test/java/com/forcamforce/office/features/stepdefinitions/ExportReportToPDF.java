package com.forcamforce.office.features.stepdefinitions;

import com.forcamforce.office.steps.PerformanceAnalysis;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;


/**
 * @author Kiran Nandarapalli
 *
 */

public class ExportReportToPDF {

	@Steps
	PerformanceAnalysis user;
	
	@Given("^user logged in the FFOffice application$")
	public void user_logged_in_the_FFOffice_application() throws Throwable {
		user.opens_the_FFOfficeApplication();
		user.logged_into_the_FFOfficeApplication();
	}
	
	@And("^user clicks performance analysis module$")
	public void user_clicks_performance_analysis_module() throws Throwable {
	   user.clicked_the_performance_analysis_tab();
	   
	}

	@And("^user on reports page$")
	public void user_on_reports_page() throws Throwable { 
	    user.clicked_reporting_tab();
	}

	@When("^user clicks the existing report in left navigation panel$")
	public void user_clicks_the_existing_report_in_left_navigation_panel() throws Throwable {
	  user.select_the_existing_report();
	  
	}

	@And("^select workplace and click refresh$")
	public void the_selected_report_displays_right_side_page_with_PDF_button_enabled() throws Throwable {
	  user.selects_the_workplace_and_clicks_refresh_button();
	}

	@And("^user clicks on PDF button$")
	public void user_clicks_on_PDF_button() throws Throwable {
	  user.cliks_the_Export_PDF_Button();

	}

	@Then("^selected report is exported to PDF and downloaded$")
	public void selected_report_is_exported_to_PDF_and_downloaded() throws Throwable {
	   user.click_the_Download_Button();
	}


}
