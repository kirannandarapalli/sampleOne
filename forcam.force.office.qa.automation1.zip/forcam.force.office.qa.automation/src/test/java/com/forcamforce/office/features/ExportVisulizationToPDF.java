package com.forcamforce.office.features;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

/**
 * @author Kiran Nandarapalli
 *
 */

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
		features="src/test/resources/features/performance_analysis/visualization/ExportVisualizationToPDF.feature")
public class ExportVisulizationToPDF {

}
